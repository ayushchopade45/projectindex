import { Component, NgModule } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { FormControl,FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  constructor(private router:Router){

  }
  ngOnInit():void{

  }
  user_record: any[] = [];
  data = {
    name: '',
    email: '',
    mobile: '',
    password: '',
  };
  doRegistration(Values: any) {
    this.user_record = JSON.parse(localStorage.getItem('users') || '[]');
    if (
      this.user_record.some((v) => {
        return v.email == this.data.email;
      })
    ) {
      alert('User already exists');
    } else {
      this.user_record.push(this.data);
      localStorage.setItem('users', JSON.stringify(this.user_record));
      alert('Sucessfull registration');
      this.router.navigate(['/login']);
    }
  }
}
