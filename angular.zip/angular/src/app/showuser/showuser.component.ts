import { Component } from '@angular/core';
import { InfoService } from '../info.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-showuser',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './showuser.component.html',
  styleUrl: './showuser.component.css'
})
export class ShowuserComponent {
user_records:any[]=[];

constructor(private udta:InfoService){
  
}
ngOnInit():void{
  this.user_records=this.udta.getu();
}

}
