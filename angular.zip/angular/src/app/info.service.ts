import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class InfoService {

  constructor() { }
  private user_data:any[]=[];
  private data={

  };
  getu():any[]{
    return this.user_data;
  }
  setu(data:any[]):void{
    this.user_data=data;
  }
}
