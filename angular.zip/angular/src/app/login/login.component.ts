import { Component } from '@angular/core';
import { NgControl, NgForm } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { InfoService } from '../info.service';
import { NgFor } from '@angular/common';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  constructor(private router: Router, private udta: InfoService) {}
  ngOnInit(): void {}
  user_record: any[] = [];
  data = {
    email: '',

    password: '',
  };
  user_record1: any[] = [];
  dologin(Values: any) {
    this.user_record = JSON.parse(localStorage.getItem('users') || '[]');
    const loggedInUser = this.user_record.find(
      (v) => v.email === this.data.email && v.password === this.data.password
    );

    if (loggedInUser) {
      alert('Login successful');
      this.udta.setu([loggedInUser]);
      this.router.navigate(['/showuser']);
    } else {
      alert('Login failed');
    }
  }
}
